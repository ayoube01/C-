# -*- coding: latin-1 -*-
from pylab import *
from time  import clock

# -----------------------------------------------------
#import routines_fortran       # :si on souhaite �crire routines_fortran.toto(5)
from routines_fortran import * # :si on souhaite �crire seulement        toto(5)
# -----------------------------------------------------

## ----------------------------------------------------- ##
##              Mes Fonctions/Procedures:                ##
## ----------------------------------------------------- ##
def fonc(i): return i**2

def matvec_py(A,x):
    m=size(A,0) 
    n=size(A,1)
    y=zeros(n)
    for i in range(n):
        for j in range(m):
            y[i] = y[i] + A[j,i]*x[j] 
    return y

## ----------------------------------------------------- ##
##            Mon Programme Principal:                   ##
## ----------------------------------------------------- ##
def main():
  print ""
  # -----------------------------------------------------
  print toto.__doc__          # test/doc toto() ...
  toto(5)
  print "------------------------------------------------"

  # -----------------------------------------------------
  print norme_bipoint.__doc__ # test/doc norme_bipoint() ...
  print("norme_bipoint(3,4) = "+str( norme_bipoint(3,4) ))
  print "------------------------------------------------"

  # -----------------------------------------------------
  print norme_vecteur.__doc__ # test/doc norme_vecteur() ...
  print("norme_vecteur(ones(9)) = "+str( norme_vecteur(ones(9)) ))
  print "------------------------------------------------"

  # -----------------------------------------------------
  print prodmatvec.__doc__    # test/doc prodmatvec() ...
  print "------------------------------------------------"
  n=4096; 
  print("Produit Matrice-Vecteur pour n = "+str(n))
  A=ones((n,n)); x=ones(n)
  t0=clock(); ydot=dot(A,x)        # :Mat-Vec par dot(.,.) de python-pylab
  print(" --> Mat-Vec par dot()  : temps (dot       ) = "+str(clock()-t0)+" s.")
  t0=clock(); y_py=matvec_py(A,x)  # :Mat-Vec par boucles for en python
  print(" --> Mat-Vec en python  : temps (matvec_py ) = "+str(clock()-t0)+" s.")
  t0=clock(); ypmv=prodmatvec(A,x) # :Mat-Vec par boucles for en Fortran
  print(" --> Mat-Vec en Fortran : temps (prodmatvec) = "+str(clock()-t0)+" s.")
  c=all( abs(y_py-ydot)<1.0e-15 )
  print(" --> Bon fonctionnement de matvec_py : "+str(c))
  b=all( abs(ypmv-ydot)<1.0e-15 )
  print(" --> Bon fonctionnement de prodmatvec: "+str(b))
  print ""

## ----------------------------------------------------- ##
##       Appel du Programme Principal:                   ##
## ----------------------------------------------------- ##
if __name__ == '__main__':
	main()

