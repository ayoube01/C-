/* === fichier: mes_structures.h === */

#ifndef _MES_STRUCTURES_H
#define _MES_STRUCTURES_H


typedef struct {  int n;        /* #coeff du vecteur       */
                  double *tab;  /* coefficients du vecteur */
               } Vecteur;

typedef struct {  int m;        /* #lignes   de la matrice      */
                  int n;        /* #colonnes de la matrice      */
                  double **tab; /* coefficients de la matrice   */
               } Matrice;


#endif /* _MES_STRUCTURES_H */
