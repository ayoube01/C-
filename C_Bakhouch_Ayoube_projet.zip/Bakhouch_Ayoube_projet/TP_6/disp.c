/* ===================== */
/* ====     disp:   ==== */
/* ===================== */
#include "inclusions_communes.h"

/* ------------------------------------------------------------------------- */
void disp_Vecteur(char *message, Vecteur *V)
{ int i;

  printf("%s\n",message);
  for (i=1; i<=V->n; i++) printf("%24.16e\n",V->tab[i]);
  
  printf("\n");
}

/* ------------------------------------------------------------------------- */
void disp_Matrice(char *message, Matrice *M)
{ int i,j;

  printf("%s\n",message);
  for (i=1; i<=M->m; i++) {
    for (j=1; j<=M->n; j++) printf("%9.2e  ",M->tab[i][j]);
    printf("\n");
  }
  
  printf("\n");
}

/* ------------------------------------------------------------------------- */
