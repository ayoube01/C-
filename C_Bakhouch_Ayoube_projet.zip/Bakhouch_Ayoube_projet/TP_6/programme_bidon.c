/* ===================================================== */
/* === programme de comparaison de temps de calcul:  === */
/* ===================================================== */

#include "inclusions_communes.h"

int main(int narg, char **arg){ /*  <-- s'emploit ainsi: ./a.out 100  */

    double t0, t1, temps;
    double alpha = 1;
    int i, j;
    int n = 10000;

    Matrice *A;
    Vecteur *x, *y, *z;

    A=zeros_Matrice(n,n);
    x=alloc_Vecteur(n);
    y=alloc_Vecteur(n);
    z=alloc_Vecteur(n);

   for (i=1; i<=n; i++)
      for (j=1; j<=n; j++) affecte_Matrice(-1.0, A, i,j);
    affecte_Matrice((double) n, A, 1,1);
    for (i=2; i<=n; i++) affecte_Matrice((double) (n-1), A, i,i);

    for (i=1; i<=n; i++) affecte_Vecteur((double) (i%2), x, i);
    for (i=1; i<=n; i++) affecte_Vecteur((double) (i%2), y, i);
    for (i=1; i<=n; i++) affecte_Vecteur((double) (i%2), z, i);



    t0=omp_get_wtime();
    for (i=1;i<=n;i++) SAXPY(z,alpha,x,y);
    t1=clock(); temps=(double) (t1-t0)/CLOCKS_PER_SEC;
    printf("--->  SAXPY (omp_get_wtime) = %f s\n\n",temps);

    t0=omp_get_wtime();
    for (i=1;i<=n;i++) alpha = DOT(x,y);
    t1=clock(); temps=(double) (t1-t0)/CLOCKS_PER_SEC;
    printf("--->  DOT (omp_get_wtime) = %f s\n\n",temps);



    return 0;
}
