/* ================== */
/*       tools.c:     */
/* ================== */

#include "inclusions_communes.h"


/* ============      Pour Vecteur:       ============== */

/* ------------------------------------------- */
/* ====   Acces aux Composantes/Champs:   ==== */
/* ------------------------------------------- */
void affecte_Vecteur(double valeur, Vecteur *V, int i)
{ assert( V );
  assert( 1<=i && i<=V->n );
  V->tab[i] = valeur;
}

double coeff_Vecteur(Vecteur *V, int i)
{ assert( V );
  assert( 1<=i && i<=V->n );
  return V->tab[i];
}

int length_Vecteur(Vecteur *V)
{ assert( V );
  return V->n;
}

/* ------------------------------------------------------------------------- */
Vecteur *zeros_Vecteur(int n)
{ int i;
  Vecteur *V=alloc_Vecteur(n);
  for (i=1; i<=n; i++) affecte_Vecteur(0.0, V, i);
  return V;
}

/* ------------------------------------------------------------------------- */
Vecteur *ones_Vecteur(int n)
{ int i;
  Vecteur *V=alloc_Vecteur(n);
  for (i=1; i<=n; i++) affecte_Vecteur(1.0, V, i);
  return V;
}

/* ------------------------------------------------------------------------- */
Vecteur *rand_Vecteur(int n)
{ int i;
  Vecteur *V=alloc_Vecteur(n);
  srand(time(0));  
  for (i=1; i<=n; i++) affecte_Vecteur(rand()/(RAND_MAX+1.0), V, i);
  return V;
}



/* ============      Pour Matrice:       ============== */

/* ------------------------------------------- */
/* ====   Acces aux Composantes/Champs:   ==== */
/* ------------------------------------------- */
void affecte_Matrice(double valeur, Matrice *M, int i, int j)
{ assert( M );
  assert( 1<=i && i<=M->m );
  assert( 1<=j && j<=M->n );
  M->tab[i][j] = valeur;
}

double coeff_Matrice(Matrice *M, int i, int j)
{ assert( M );
  assert( 1<=i && i<=M->m );
  assert( 1<=j && j<=M->n );
  return M->tab[i][j];
}

int nrows_Matrice(Matrice *M)
{ assert( M );
  return M->m;
}

int ncols_Matrice(Matrice *M)
{ assert( M );
  return M->n;
}

/* ------------------------------------------------------------------------- */
Matrice *zeros_Matrice(int m, int n)
{ int i, j;
  Matrice *M=alloc_Matrice(m, n);
  
  for (i=1; i<=m; i++) 
    for (j=1; j<=n; j++) affecte_Matrice(0.0, M, i, j);
    
  return M;
}

/* ------------------------------------------------------------------------- */
Matrice *ones_Matrice(int m, int n)
{ int i, j;
  Matrice *M=alloc_Matrice(m, n);
  
  for (i=1; i<=m; i++) 
    for (j=1; j<=n; j++) affecte_Matrice(1.0, M, i, j);
    
  return M;
}

/* ------------------------------------------------------------------------- */
Matrice *rand_Matrice(int m, int n)
{ int i, j;
  Matrice *M=alloc_Matrice(m, n);
  
  srand(time(0));  
  for (i=1; i<=m; i++) 
    for (j=1; j<=n; j++) affecte_Matrice(rand()/(RAND_MAX+1.0), M, i, j);
    
  return M;
}

