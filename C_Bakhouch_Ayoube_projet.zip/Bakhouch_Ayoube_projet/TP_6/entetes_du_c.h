/* === fichier: entetes_du_c.h === */
#ifndef _ENTETES_DU_C_H
#define _ENTETES_DU_C_H


#include <math.h>   /* sqrt()...         */
#include <stdio.h>  /* printf()...       */
#include <stdlib.h> /* malloc()...       */
#include <stddef.h> /* NULL...           */
#include <string.h> /* atof,memcpy...    */
#include <time.h>   /* clock()...        */
#include <limits.h> /* bornes limites... */
#include <assert.h> /* assert()...       */
#include <omp.h>

#endif /* _ENTETES_DU_C_H */

