
/* ================================================================== */
/* ===               INCLUSION DES LIBRAIRIES DU C                === */
/* ================================================================== */
#include <math.h>   /* sqrt()...         */
#include <stdio.h>  /* printf()...       */
#include <stdlib.h> /* malloc()...       */
#include <stddef.h> /* NULL...           */
#include <string.h> /* atof,memcpy...    */
#include <time.h>   /* clock()...        */
#include <limits.h> /* bornes limites... */
#include <assert.h> /* assert()...       */
#include <omp.h>    /* OpenMP */


/* ================================================================== */
/* ===                  DEFINITION DES MACROS                     === */
/* ================================================================== */
#define min(a,b) ( (a)<(b) ? (a) : (b) )
#define max(a,b) ( (a)>(b) ? (a) : (b) )
#define CARRE(x) ( (x)*(x) )
#define  CUBE(x) ( (x)*(x)*(x) )
#define   ABS(x) ( (x)>=0 ? (x) : -(x) )
#define  SIGN(x) ( (x)>0 ? (+1) : ( (x)<0 ? (-1) : (0) ) )

#define Inf  (1.0/0.0)
#define NaN  (0.0/0.0)
#define PI      3.141592653589793e+000
#define CAS_PB  1

/* ================================================================== */
/* ===                  DECLARATION DES STRUCTURES                === */
/* ================================================================== */

typedef struct {  
    int     length; /* nombre de coeff.  du vecteur */
    double *tab;    /* les coefficients  du vecteur */
} Vecteur;

/* ================================================================== */
/* ===                  DECLARATION DES ENTETES                   === */
/* ================================================================== */

double *alloc_dtab_1d(int n);
double *free_dtab_1d(double *v);
Vecteur *alloc_Vecteur(int n);
Vecteur *free_Vecteur(Vecteur *V);
void   disp_Vecteur(char *message, Vecteur *V);
double dot(double *v, double *w, int d, int f);
double NORM    (Vecteur *x);
double NORM_INF(Vecteur *x);

void saxpy(double *z, double alpha, double *x, double *y, int d, int f); 

double fct_kappa(double x);
double fct_f    (double x);
double fct_p    (double x);
double fct_u    (double x);


/* ================================================================== */
/* ===                   DEFINITION DES FONCTIONS                 === */
/* ================================================================== */

/* ===================== */
/* allocation dynamique: */
/* ===================== */
/* ------------------------------------------------------------------------- */
double *alloc_dtab_1d(int n)
{ assert( n>0 ); 
  { double *v=NULL;
  
    v = (double *) calloc (n, sizeof(double));
    if (v == NULL) {
      printf("plus de place pour alloc_dtab_1d()\n"); exit(1);
    } 
    v = v-1;
  
    return v;
  }
}

double *free_dtab_1d(double *v)
{ if (v!=NULL) free(v+1);
  return NULL;
}

Vecteur *alloc_Vecteur(int n)
{ assert( n>0 ); 
  { Vecteur *V=NULL;
  
    V = (Vecteur *) malloc(sizeof(Vecteur));
    if (V == NULL) {
      printf("plus de place pour alloc_Vecteur()\n"); exit(1);
    };
    V->length = n;
    V->tab    = alloc_dtab_1d(n);
    return V;
  }
}

Vecteur *free_Vecteur(Vecteur *V)
{ if (V!=NULL) {
    free_dtab_1d(V->tab);
    free(V);
  }
  return NULL;
}


/* ===================== */
/* ====     disp:   ==== */
/* ===================== */
/* ------------------------------------------------------------------------- */
void disp_Vecteur(char *message, Vecteur *V)
{ assert(V!=NULL); 
  { int i;

    printf("%s\n",message);
    for (i=1; i<=V->length; i++) printf("%24.16e\n",V->tab[i]);
    
    printf("\n");
  }
}


/* ============ */
/* === BLAS === */
/* ============ */
/* -------------------------- BLAS de bas niveau --------------------------- */
double dot(double *v, double *w, int d, int f)  
/* v(d:f)'*w(d:f) */
{ assert(v!=NULL); assert(w!=NULL); 
  { int    i; 
    double s=0.0;
  
    for (i=d; i<=f; i++) s += v[i]*w[i];
    
    return s;
  }
}

/* -------------------------- BLAS de haut niveau -------------------------- */
double NORM(Vecteur *x)  
/* ||x||_2 = sqrt( (x|x) ) */
{ assert(x!=NULL); 
  { return sqrt(dot(x->tab, x->tab, 1, x->length));
  }
}

double NORM_INF(Vecteur *x)  
/* ||x||_inf = max_{1<=i<=n} |x_i| */
{ assert(x!=NULL); 
  { int i; 
    double nx=0.0; 
  
    for (i=1; i<=x->length; i++) nx = max(nx, fabs(x->tab[i]));
    
    return nx;
  }
}

double dot(double *v, double *w, int d, int f)  
/* v(d:f)'*w(d:f) */
{ int i; double s=v[d]*w[d];
  for (i=d+1; i<=f; i++) s += v[i]*w[i];
  return s;
}

void saxpy(double *z, double alpha, double *x, double *y, int d, int f)  

{
  #ifndef _CBLAS_
  int i;  
  for (i=d; i<=f; i++) z[i] = alpha*x[i]+y[i];
  #else
  if (z != y) cblas_dcopy(f-d+1, &y[d], 1, &z[d], 1);
  cblas_daxpy(f-d+1, alpha, &x[d], 1, &z[d], 1);
  #endif
}


