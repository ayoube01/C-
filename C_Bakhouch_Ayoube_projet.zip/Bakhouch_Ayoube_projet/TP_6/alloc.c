/* ============================= */
/* === allocation dynamique: === */
/* ============================= */
#include "inclusions_communes.h"

/* ------------------------------------------------------------------------- */
double *alloc_dtab_1d(int n)
{ double *v=NULL;
  assert( n>0 );

  v=(double *) calloc ((size_t) n, sizeof(double));
  if (v == NULL) {
    printf("plus de place pour alloc_dtab_1d()\n"); exit(EXIT_FAILURE);
  } 
  v=v-1;

  return v;
}

double *free_dtab_1d(double *v)
{ if ( v ) free(v+1);
  return NULL; 
}

/* ------------------------------------------------------------------------- */


/*Même principe que dtab; sauf qu'on alloue pour la taille d'un*/

int *alloc_itab_1d(int n)
{ int *v=NULL;
  assert( n>0 );

  v=(int *) calloc ((size_t) n, sizeof(int));
  if (v == NULL) {
    printf("plus de place pour alloc_itab_1d()\n"); exit(EXIT_FAILURE);
  } 
  v=v-1;

  return v;
}

int *free_itab_1d(int *v)
{ if ( v ) free(v+1);
  return NULL;
}

/* ------------------------------------------------------------------------- */
double **alloc_dtab_2d(int m, int n)
{ int i;
  double **M=NULL;
  assert( m>0 && n>0 );
 
  /* allocation des pointeurs de lignes */
  M=(double **) calloc((size_t) m, sizeof(double *));
  if (M == NULL) {
    printf("plus de place pour alloc_dtab_2d()\n"); exit(EXIT_FAILURE);
  } 
  M=M-1;

  /* allocation des lignes et affectation de leur pointeur */
  M[1]=(double *) calloc((size_t) (m*n), sizeof(double));
  if (M[1] == NULL) {
    printf("plus de place pour alloc_dtab_2d()\n"); exit(EXIT_FAILURE);
  } 
  M[1]=M[1]-1;
  for(i=1; i<=m-1; i++) M[i+1]=M[i]+n;

  return M;
}

double **free_dtab_2d(double **M)
{ if ( M ) {
    free(M[1]+1);
    free(M+1);
  }
  return NULL;
}

/* ------------------------------------------------------------------------- */
Matrice *alloc_Matrice(int m, int n)
{ Matrice *M=NULL;
  assert( m>0 && n>0 );

  M=(Matrice *) malloc(sizeof(Matrice));
  if (M == NULL) {
    printf("plus de place pour alloc_Matrice()\n"); exit(EXIT_FAILURE);
  };
  M->m=m; M->n=n;
  M->tab=alloc_dtab_2d(m,n);

  return M;
}

Matrice *free_Matrice(Matrice *M)
{ if ( M ) {
    M->tab=free_dtab_2d(M->tab);
    free(M);
  }
  return NULL;
}

/* ------------------------------------------------------------------------- */
Vecteur *alloc_Vecteur(int n)
{ Vecteur *V=NULL;
  assert( n>0 );

  V=(Vecteur *) malloc(sizeof(Vecteur));
  if (V == NULL) {
    printf("plus de place pour alloc_Vecteur()\n"); exit(EXIT_FAILURE);
  };
  V->n=n;
  V->tab=alloc_dtab_1d(n);

  return V;
}

Vecteur *free_Vecteur(Vecteur *V)
{ if ( V ) {
    V->tab=free_dtab_1d(V->tab);
    free(V);
  }
  return NULL;
}
/* ------------------------------------------------------------------------- */



