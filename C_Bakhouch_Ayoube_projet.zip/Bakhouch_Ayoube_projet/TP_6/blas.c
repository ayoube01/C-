/* ============== */
/* ===  BLAS: === */
/* ============== */
#include "inclusions_communes.h"

/* -------------------------- BLAS de bas niveau --------------------------- */
double dot(double *v, double *w, int d, int f)  
/* v(d:f)'*w(d:f) */
{ int i; double s=v[d]*w[d];
	
#pragma omp parallel for reduction(+:s)
  for (i=d+1; i<=f; i++) s += v[i]*w[i];
  return s;
}

void saxpy(double *z, double alpha, double *x, double *y, int d, int f)  
/* z(d:f) = a.*x(d:f)+y(d:f)' */
{
  #ifndef _CBLAS_
  int i;  
  #pragma omp parallel for private(i)
  for (i=d; i<=f; i++) z[i] = alpha*x[i]+y[i];
  #else
  if (z != y) cblas_dcopy(f-d+1, &y[d], 1, &z[d], 1);
  cblas_daxpy(f-d+1, alpha, &x[d], 1, &z[d], 1);
  #endif
}



void xpy(double *z, double *x, double *y, int d, int f)  
/* z(d:f) = x(d:f)+y(d:f) */
{ int i;  
  for (i=d; i<=f; i++) z[i] = x[i]+y[i];
}

void xmy(double *z, double *x, double *y, int d, int f)  
/* z(d:f) = x(d:f)-y(d:f) */
{ int i;  
  for (i=d; i<=f; i++) z[i] = x[i]-y[i];
}

void xfy(double *z, double *x, double *y, int d, int f)  
/* z(d:f) = x(d:f).*y(d:f) */
{ int i;  
  for (i=d; i<=f; i++) z[i] = x[i]*y[i];
}

void xdy(double *z, double *x, double *y, int d, int f)  
/* z(d:f) = x(d:f)./y(d:f) */
{ int i;  
  for (i=d; i<=f; i++) z[i] = x[i]/y[i];
}

void opu(double **R, double a, double *x, double *y, int d, int f)  
/* R(d:f,d:f) += a.*x(d:f)*y(d:f)' !! seulement pour matrices CARREES */
{ int i;
  for (i=d; i<=f; i++) saxpy(R[i], a*x[i], y, R[i], d, f);
}

void matvec(double *y, double **A, double *x, int m, int n)  
/* y(1:m) = A(1:m,1:n)*x(1:n) */
{ int i;
	#pragma omp parallel for private(i)
  for (i=1; i<=m; i++) y[i] = dot(A[i], x, 1, n);
}

void residu(double *r, double *b, double **A, double *x, int m, int n)  
/* r(1:m) = b(1:m)-A(1:m,1:n)*x(1:n) */
{ matvec(r, A, x, m, n);         /* r = A*x */
  xmy(r, b, r, 1, m);            /* r = b-r */
}

void descente(double *x, double **L, double *b, int d, int f)
/* x(d:f)? / L(d:f,d:f)x(d:f) = b(d:f) avec L=triang. inf. */
{ int i;
  x[d] = b[d]/L[d][d];
  for (i=d+1; i<=f; i++) x[i] = ( b[i]-dot(L[i], x, d, i-1) )/L[i][i];
}

void remontee(double *x, double **U, double *b, int d, int f)
/* x(d:f)? / U(d:f,d:f)x(d:f) = b(d:f) avec U=triang. sup.*/
{ int i;
  x[f] = b[f]/U[f][f];
  for (i=f-1; i>=d; i--) x[i] = ( b[i]-dot(U[i], x, i+1, f) )/U[i][i];
}

/* ----------------------- BLAS du bas au HAUT niveau ----------------------- */
double DOT(Vecteur *v, Vecteur *w)  
/* v'*w */
{ assert( (v->n == w->n) );
  return dot(v->tab, w->tab, 1, v->n);
}

void SAXPY(Vecteur *z, double alpha, Vecteur *x, Vecteur *y)  
/* z = a.*x+y' */
{ assert( (x->n == y->n) && (x->n == z->n) );
  saxpy(z->tab, alpha, x->tab, y->tab, 1, x->n);
}

void XPY(Vecteur *z, Vecteur *x, Vecteur *y)  
/* z = x+y */
{ assert( (x->n == y->n) && (x->n == z->n) );
  xpy(z->tab, x->tab, y->tab, 1, x->n);
}

void XMY(Vecteur *z, Vecteur *x, Vecteur *y)  
/* z = x-y */
{ assert( (x->n == y->n) && (x->n == z->n) );
  xmy(z->tab, x->tab, y->tab, 1, x->n);
}

void XFY(Vecteur *z, Vecteur *x, Vecteur *y)  
/* z = x.*y */
{ assert( (x->n == y->n) && (x->n == z->n) );
  xfy(z->tab, x->tab, y->tab, 1, x->n);
}

void XDY(Vecteur *z, Vecteur *x, Vecteur *y)  
/* z = x./y */
{ assert( (x->n == y->n) && (x->n == z->n) );
  xdy(z->tab, x->tab, y->tab, 1, x->n);
}

double NORM(Vecteur *x)  
/* ||x||_2 = sqrt( (x|x) ) */
{ return sqrt(dot(x->tab, x->tab, 1, x->n));
}

double NORM_INF(Vecteur *x)  
/* ||x||_inf = max_{1<=i<=n} |x_i| */
{ int i; double nx=0.0; 
  for (i=1; i<=x->n; i++) nx = max(nx,fabs(x->tab[i]));
  return nx;
}

void OPU(Matrice *R, double a, Vecteur *x, Vecteur *y, int d, int f)  
/* R += a.*x*y' !! seulement pour matrices CARREES */
{ assert(R->m == R->n); assert(x->n == y->n);
  assert(1 <= d && d <= x->n); assert(1 <= f && f <= x->n); 
  assert(d <= f);
  opu(R->tab, a, x->tab, y->tab, d, f);
}

void MATVEC(Vecteur *y, Matrice *A, Vecteur *x)  
/* y = A*x */
{ assert( (A->m == y->n) && (A->n == x->n) );
  matvec(y->tab, A->tab, x->tab, A->m, A->n);
}

void RESIDU(Vecteur *r, Vecteur *b, Matrice *A, Vecteur *x)  
/* r = b-A*x */
{ MATVEC(r, A, x); /* r = A*x */
  XMY(r, b, r);    /* r = b-r */
}

void DESCENTE(Vecteur *x, Matrice *A, Vecteur *b)  
/* x? | A*x=b avec A triangulaire inf.*/
{ assert( A->m == A->n);
  descente(x->tab, A->tab, b->tab, 1, A->n);
}

void REMONTEE(Vecteur *x, Matrice *A, Vecteur *b)  
/* x? | A*x=b avec A triangulaire sup.*/
{ assert( A->m == A->n);
  remontee(x->tab, A->tab, b->tab, 1, A->n);
}

void VecCPY(Vecteur *z, Vecteur *x)  
/* z = x, test: OK */
{ assert( x->n == z->n );
  memcpy(&(z->tab[1]), &(x->tab[1]), x->n*sizeof(double));
}
