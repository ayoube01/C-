/* ============================= */
/* === programme principal:  === */
/* ============================= */

#include "inclusions_communes.h"

int main(int narg, char **arg) /*  <-- s'emploit ainsi: ./a.out 100  */
{
  if ( narg==1 ) {
    printf("USAGE (par exemple): ./a.out 100\n ...SORTIE !\n");
    exit(EXIT_FAILURE);
  }

  {
    clock_t t0,t1;
    double  temps;
    double  eps=1e-10;
    int i, j, n=atoi(arg[1]);
    Matrice *A;
    Morse *M;
    Vecteur *x, *b, *x0;

    A=alloc_Matrice(n,n);

    x=rand_Vecteur(n); b=alloc_Vecteur(n); x0=alloc_Vecteur(n);

    for (i=1; i<=n; i++)
      for (j=1; j<=n; j++) affecte_Matrice(-1.0, A, i,j);
    affecte_Matrice((double) n, A, 1,1);
    for (i=2; i<=n; i++) affecte_Matrice((double) (n-1), A, i,i);

    for (i=1; i<=n; i++) affecte_Vecteur((double) (i%2), b, i);

    t0=clock(); for (i=1; i<=n; i++) affecte_Vecteur(0.0, x0, i);
    Jacobi_Matrice(x, A, b, x0, eps, INT_MAX);
    t1=clock(); temps=(double) (t1-t0)/CLOCKS_PER_SEC;
    printf(" APPEL Ja --> temps = %f s\n\n",temps);

    t0=clock(); for (i=1; i<=n; i++) affecte_Vecteur(0.0, x0, i);
    Gauss_Seidel_Matrice(x, A, b, x0, eps, INT_MAX);
    t1=clock(); temps=(double) (t1-t0)/CLOCKS_PER_SEC;
    printf(" APPEL GS --> temps = %f s\n\n",temps);

    t0=clock(); for (i=1; i<=n; i++) affecte_Vecteur(0.0, x0, i);
    Relaxation_Matrice(x, A, b, x0, eps, INT_MAX, 1.89);
    t1=clock(); temps=(double) (t1-t0)/CLOCKS_PER_SEC;
    printf(" APPEL Re --> temps = %f s\n\n",temps);

    t0=clock(); for (i=1; i<=n; i++) affecte_Vecteur(0.0, x0, i);
    Gradient_Conjugue_Matrice(x, A, b, x0, eps, n*2);
    t1=clock(); temps=(double) (t1-t0)/CLOCKS_PER_SEC;
    printf(" APPEL GC --> temps = %f s\n\n",temps);


    M=Sparse_To_Morse(A);


     t0=clock(); for (i=1; i<=n; i++) affecte_Vecteur(0.0, x0, i);
    Jacobi_Morse(x, M, b, x0, eps, INT_MAX);
    t1=clock(); temps=(double) (t1-t0)/CLOCKS_PER_SEC;
    printf(" APPEL Ja Morse --> temps = %f s\n\n",temps);

    t0=clock(); for (i=1; i<=n; i++) affecte_Vecteur(0.0, x0, i);
    Gauss_Seidel_Morse(x, M, b, x0, eps, INT_MAX);
    t1=clock(); temps=(double) (t1-t0)/CLOCKS_PER_SEC;
    printf(" APPEL GS Morse --> temps = %f s\n\n",temps);

    t0=clock(); for (i=1; i<=n; i++) affecte_Vecteur(0.0, x0, i);
    Relaxation_Morse(x, M, b, x0, eps, INT_MAX, 1.89);
    t1=clock(); temps=(double) (t1-t0)/CLOCKS_PER_SEC;
    printf(" APPEL Re Morse --> temps = %f s\n\n",temps);


    if ( n<=8 ) {
      disp_Matrice(" A = ", A); disp_Morse(" M = ",M); disp_Vecteur(" b = ", b); disp_Vecteur(" x = ", x);
      save_Vecteur("b.txt", b); save_Vecteur("x.txt", x); save_Matrice("A.txt", A);
    }

    A=free_Matrice(A);
    M=free_Morse(M);
    x=free_Vecteur(x);
    b=free_Vecteur(b);
    x0=free_Vecteur(x0);

    return EXIT_SUCCESS;
  }
}
