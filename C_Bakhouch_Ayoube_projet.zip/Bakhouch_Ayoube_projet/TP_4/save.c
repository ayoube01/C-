/* ===================== */
/* ====  save/load: ==== */
/* ===================== */
#include "inclusions_communes.h"

/* ------------------------------------------------------------------------- */
void save_Vecteur_pour_Matlab(char *nomfich, Vecteur *x)
{ int i, n=x->n;
  FILE *uo;

  uo=fopen(nomfich,"wt");

  for (i=1; i<=n; i++) {
    if (isFin(x->tab[i])) 
      fprintf(uo,"%24.15e\n",x->tab[i]);
    else if (isNaN(x->tab[i])) 
      fprintf(uo,"                     NaN\n");
    else if (isInf(x->tab[i])==1) 
      fprintf(uo,"                     Inf\n");
    else if (isInf(x->tab[i])==-1) 
      fprintf(uo,"                    -Inf\n");
  }

  fclose(uo);
}

/* ------------------------------------------------------------------------- */
void save_Vecteur(char *nomfich, Vecteur *x)
{ int i, n=x->n;
  FILE *uo;

  uo=fopen(nomfich,"wt");

  fprintf(uo,"//dimension:\n");
  fprintf(uo,"%d\n",n);

  fprintf(uo,"//coefficients:\n");
  for (i=1; i<=n; i++) {
    if (isFin(x->tab[i])) 
      fprintf(uo,"%24.15e\n",x->tab[i]);
    else if (isNaN(x->tab[i])) 
      fprintf(uo,"                     NaN\n");
    else if (isInf(x->tab[i])==1) 
      fprintf(uo,"                     Inf\n");
    else if (isInf(x->tab[i])==-1) 
      fprintf(uo,"                    -Inf\n");
  }

  fclose(uo);
}

/* ------------------------------------------------------------------------- */
Vecteur *load_Vecteur(char *nomfich)
{ int i,n,nbl;
  FILE *uo;
  Vecteur *x;
  char ch[128];
 
  uo=fopen(nomfich,"rt");
  if ( uo==NULL ) {
    printf("Fichier non-existant (SORTIE).\n"); exit(EXIT_FAILURE);
  }

  nbl=fscanf(uo,"%s\n",ch); /* message */
  nbl=fscanf(uo,"%d\n",&n);
  x=alloc_Vecteur(n);

  nbl=fscanf(uo,"%s\n",ch); /* message */
  for (i=1; i<=n; i++) {
    nbl=fscanf(uo,"%s\n",ch);
    if (!strcmp(ch,"NaN"))       x->tab[i]= NaN;
    else if (!strcmp(ch,"Inf"))  x->tab[i]=+Inf;
    else if (!strcmp(ch,"-Inf")) x->tab[i]=-Inf;
    else                         x->tab[i]=atof(ch); /* rem: double atof(char *) */
  }
  
  fclose(uo);
  
  return x;
}

/* ------------------------------------------------------------------------- */
void save_Matrice(char *nomfich, Matrice *M)
{ int i,j, m=M->m, n=M->n;
  FILE *uo;

  uo=fopen(nomfich,"wt");
 
  fprintf(uo,"//dimensions:\n");
  fprintf(uo,"%d  %d\n",m,n);

  fprintf(uo,"//coefficients:\n");
  for (i=1; i<=m; i++) {
   for (j=1; j<=n; j++)
     if (isFin(M->tab[i][j])) 
       fprintf(uo,"%24.15e",M->tab[i][j]);
     else if (isNaN(M->tab[i][j])) 
       fprintf(uo,"                     NaN");
     else if (isInf(M->tab[i][j])==1) 
       fprintf(uo,"                     Inf");
     else if (isInf(M->tab[i][j])==-1) 
       fprintf(uo,"                    -Inf");
     fprintf(uo,"\n"); 
  }
 
  fclose(uo);
}

/* ------------------------------------------------------------------------- */
Matrice *load_Matrice(char *nomfich)
{ int i,j,m,n,nbl;
  FILE *uo;
  Matrice *M;
  char ch[128];
 
  uo=fopen(nomfich,"rt");
  if ( uo==NULL ) {
    printf("Fichier non-existant (SORTIE).\n"); exit(EXIT_FAILURE);
  }
  
  nbl=fscanf(uo,"%s\n",ch); /* message */
  nbl=fscanf(uo,"%d\n",&m);
  nbl=fscanf(uo,"%d\n",&n);
  M=alloc_Matrice(m,n);

  nbl=fscanf(uo,"%s\n",ch); /* message */
  for (i=1; i<=m; i++) {
    for (j=1; j<=n; j++) {
      nbl=fscanf(uo,"%s",ch);
      if (!strcmp(ch,"NaN"))       M->tab[i][j]= NaN;
      else if (!strcmp(ch,"Inf"))  M->tab[i][j]=+Inf;
      else if (!strcmp(ch,"-Inf")) M->tab[i][j]=-Inf;
      else                         M->tab[i][j]=atof(ch);
    }
    nbl=fscanf(uo,"\n");
  }
  fclose(uo);
  
  return M;
}

/* ------------------------------------------------------------------------- */

