/* ================================ */
/* ===   M�thodes It�ratives:   === */
/* ================================ */

#include "inclusions_communes.h"

/* ------------------------------------------------------------------------- */
/*                      --- m�thode de JACOBI ---                            */
/* ------------------------------------------------------------------------- */
void Jacobi_Matrice(Vecteur *x, Matrice *A, Vecteur *b, Vecteur *x0,
            double eps, int kmax)
{   int n, i;
	int k = 1;
    Vecteur *r, *d, *M;
    n = b->n;
    if ( Bavardage >= 1 ) printf(" Jacobi :\n");
    r=alloc_Vecteur(n);
    d=alloc_Vecteur(n);
    M=alloc_Vecteur(n);
    VecCPY(x,x0);
    RESIDU(r, b, A, x);
    for(i=1;i<=n;i++)
    {
        M->tab[i] = A->tab[i][i];
    }
    for (k=0; ( NORM_INF(r) > eps*NORM_INF(b) ) && (k < kmax); k++)
    {
        for (i=1;i<=n;i++)
        {
            d->tab[i] =(r->tab[i])/(M->tab[i]);
        XPY(x,x,d);
        RESIDU(r, b, A, x);
        k++;
		}
    }
		if ( Bavardage >= 1 ) {
        printf("%d iterations |r|/|b|=%2.16e\n",k,NORM_INF(r)/NORM_INF(b));
        printf(" Jacobi :\n");
		}
    r=free_Vecteur(r);
    d=free_Vecteur(d);
    M=free_Vecteur(M);
}

void Jacobi_Morse(Vecteur *x, Morse *A, Vecteur *b, Vecteur *x0, double eps, int kmax)
{   int n, i;
	int k = 1;
    Vecteur *r, *d, *M;
    n = b->n;
    if ( Bavardage >= 1 ) printf("  -> Jacobi Morse ... entree:\n");
    r=alloc_Vecteur(n);
    d=alloc_Vecteur(n);
    M=alloc_Vecteur(n);
    printf("%f",Morse_coef(A,1,1));
    VecCPY(x,x0);                               /* x = x0 */
    RESIDU_MORSE(r, b, A, x);                         /* r = b - A*x  */
    for(i=1;i<=n;i++)
    {
        M->tab[i] = Morse_coef(A,i,i);
    }
    for (k=0; ( NORM_INF(r) > eps*NORM_INF(b) ) && (k < kmax); k++)
    {
        for (i=1;i<=n;i++)
        {
			d->tab[i] = r->tab[i]/M->tab[i];
        }

        XPY(x,x,d);                             /* x = x + d  */
        RESIDU_MORSE(r, b, A, x);                     /* r = b - A*x  */
        k++;
    }
    if ( Bavardage >= 1 ) {
        printf("%d iterations |r|/|b|=%2.16e\n",k,NORM_INF(r)/NORM_INF(b));
        printf("  -> Jacobi ... sortie.\n");
    }
    r=free_Vecteur(r);
    d=free_Vecteur(d);
    M=free_Vecteur(M);
    return;
}

/* ------------------------------------------------------------------------- */
/*                      --- m�thode de GAUSS-SEIDEL ---                      */
/* ------------------------------------------------------------------------- */
void Gauss_Seidel_Matrice(Vecteur *x, Matrice *A, Vecteur *b, Vecteur *x0,
                  double eps, int kmax)
{  int n, i, j;
	int k = 1;
    Vecteur *r, *d;
    Matrice *M;
    n = b->n;
    if ( Bavardage >= 1 ) printf(" Gauss-Seidel :\n");
    r=alloc_Vecteur(n);
    d=alloc_Vecteur(n);
    M=alloc_Matrice(n,n);
    VecCPY(x,x0);
    RESIDU(r, b, A, x);
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=i;j++)
        {
            M->tab[i][j] = A->tab[i][j];
        }
    }
    for (k=0; ( NORM_INF(r) > eps*NORM_INF(b) ) && (k < kmax); k++){
        DESCENTE(d, M, r);
        XPY(x,x,d);                             /* x = x + d  */
        RESIDU(r, b, A, x);                     /* r = b - A*x  */
        k++;
    }
    if ( Bavardage >= 1 ) {
        printf("%d iterations |r|/|b|=%2.16e\n",k,NORM_INF(r)/NORM_INF(b));
        printf("  -> Gauss-Seidel ... sortie.\n");
    }
    r=free_Vecteur(r);
    d=free_Vecteur(d);
    M=free_Matrice(M);
}

void Gauss_Seidel_Morse(Vecteur *x, Morse *A, Vecteur *b, Vecteur *x0, double eps, int kmax)
{	int n;
	int k = 1;
    Vecteur *r, *d;
    Morse *M;
    n = b->n;
    if ( Bavardage >= 1 ) printf("  -> Gauss-Seidel Morse ... entree:\n");
    r=alloc_Vecteur(n);
    d=alloc_Vecteur(n);
    VecCPY(x,x0);
    RESIDU_MORSE(r, b, A, x);
    M=TriInf_To_Morse(A);
    for (k=0; ( NORM_INF(r) > eps*NORM_INF(b) ) && (k < kmax); k++){
        DESCENTE_MORSE(d, M, r);
        XPY(x,x,d);
        RESIDU_MORSE(r, b, A, x);
        k = k+1;
    }
    if ( Bavardage >= 1 )
    {
        printf("%d iterations |r|/|b|=%2.16e\n",k,NORM_INF(r)/NORM_INF(b));
        printf("  -> Gauss-Seidel ... sortie.\n");
    }
    r=free_Vecteur(r);
    d=free_Vecteur(d);
    M=free_Morse(M);
    return;
}

/* ------------------------------------------------------------------------- */
/*                      --- m�thode de RELAXATION ---                        */
/* ------------------------------------------------------------------------- */
void Relaxation_Matrice(Vecteur *x, Matrice *A, Vecteur *b, Vecteur *x0,
                double eps, int kmax, double w)
{	int n, i, j;
	int k = 1;
    Vecteur *r, *d;
    Matrice *M;
    n = length_Vecteur(b);
    if ( Bavardage >= 1 ) printf("  -> Relaxation :\n");
    r=alloc_Vecteur(n);
    d=alloc_Vecteur(n);
    M=alloc_Matrice(n,n);
    VecCPY(x,x0);
    RESIDU(r, b, A, x);
    for(i=1;i<=n;i++){
        for(j=1;j<=i;j++){
            if (i==j){
               M->tab[i][j] = A->tab[i][j]/w;
            }
            else{
                M->tab[i][j] = A->tab[i][j];
            }
        }
    }
   for (k=0; ( NORM_INF(r) > eps*NORM_INF(b) ) && (k < kmax); k++){
        DESCENTE(d, M, r);
        XPY(x,x,d);
        RESIDU(r, b, A, x);
        k++;
    }
    if ( Bavardage >= 1 )
    {
        printf("%d iterations |r|/|b|=%2.16e\n",k,NORM_INF(r)/NORM_INF(b));
        printf("  -> Relaxation.");
    }
    r=free_Vecteur(r);
    d=free_Vecteur(d);
    M=free_Matrice(M);

}
/*------------------------------------Relaxation___MORSE---------------------------*/
void Relaxation_Morse(Vecteur *x, Morse *A, Vecteur *b, Vecteur *x0, double eps, int kmax, double w)
{   int n, i, j;
	int k = 1;
    Vecteur *r, *d;
    Matrice *temp;
    Morse *M;
    n = b->n;
    if ( Bavardage >= 1 ) printf("  -> Relaxation Morse ... entree:\n");
        /* ----------------------- allocation: --- */
    r=alloc_Vecteur(n);
    d=alloc_Vecteur(n);
    temp=zeros_Matrice(n,n);
     /* --------------l'initialisation: -------------------------- */
    VecCPY(x,x0);
    RESIDU_MORSE(r, b, A, x);
    for(i=1;i<=n;i++)
    {
        for(j=1;j<=i;j++)
        {
            if (i==j)
            {
                temp->tab[i][j] = Morse_coef(A,i,j)/w;
            }
            else
            {
                temp->tab[i][j] = Morse_coef(A,i,j);
            }
        }
    }
        M=Sparse_To_Morse(temp);
   for (k=0; ( NORM_INF(r) > eps*NORM_INF(b) ) && (k < kmax); k++){
        DESCENTE_MORSE(d, M, r);
        XPY(x,x,d);
        RESIDU_MORSE(r, b, A, x);
        k++;
    }
        if ( Bavardage >= 1 )
    {
        printf("%d iterations |r|/|b|=%2.16e\n",k,NORM_INF(r)/NORM_INF(b));
        printf("  -> Relaxation ... sortie.\n");
    }
        r=free_Vecteur(r);
    temp=free_Matrice(temp);
    d=free_Vecteur(d);
    M=free_Morse(M);
    }

/* ------------------------------------------------------------------------- */
/*           --- m�thode du gradient conjugu� pr�conditionn� ---             */
/* ------------------------------------------------------------------------- */
void Gradient_Conjugue_Matrice(Vecteur *x, Matrice *A, Vecteur *b, Vecteur *x0,
                       double eps, int kmax)
{


  int i, k, n=A->n;
  double alpha, beta;
  Vecteur *p0, *r0, *d0, *z0;
  Vecteur *D , *r , *d , *z ;

  assert(A->m ==  A->n); assert(A->n == b->n);
  assert(A->n == x0->n); assert(A->n == x->n);

  if ( Bavardage >= 1 ) printf("  -> Gradient_Conjugue ... entree:\n");

                      /* ---      allocation:        --- */
  r0=alloc_Vecteur(n); d0=alloc_Vecteur(n); z0=alloc_Vecteur(n); p0=alloc_Vecteur(n);
  r =alloc_Vecteur(n); d =alloc_Vecteur(n); z =alloc_Vecteur(n); D =alloc_Vecteur(n);

                   /* --- pr�conditionneur diagonal: --- */
  for (i=1; i<=n; i++) D->tab[i] = coeff_Matrice(A,i,i); /* A->tab[i][i] */

                      /* --- l'initialisation: --- */
  RESIDU(r0, b, A, x0);                /* r0 = b - A*x0  */
  XDY(z0, r0, D);                      /* z0 = r0./D     */
  VecCPY(d0, z0);                      /* d0 = z0        */

                      /* --- les it�rations: --- */
  for (k=0; ( NORM_INF(r0) > eps*NORM_INF(b) ) && (k < kmax); k++) {
    MATVEC(p0, A, d0);                  /* p0 = A*d0                 */
    alpha = DOT(z0, r0)/DOT(d0, p0);    /* alpha = (z0|r0) / (d0|p0) */
    SAXPY(x, alpha, d0, x0);            /* x =  alpha*d0 + x0        */
    SAXPY(r,-alpha, p0, r0);            /* r = -alpha*p0 + r0        */
    XDY(z, r, D);                       /* z = r./D                  */
    beta = DOT(z, r)/DOT(z0, r0);       /* beta = (z|r) / (z0|r0)    */
    SAXPY(d, beta, d0, z);              /* d =  beta*d0 + z          */
    VecCPY(x0, x); VecCPY(r0, r);       /* x0=x, r0=r                */
    VecCPY(z0, z); VecCPY(d0, d);       /* z0=z, d0=d                */
    if ( Bavardage >= 2 ) printf("k=%d, |r0|=%e\n",k,NORM_INF(r0));
  }

  if ( Bavardage >= 1 ) {
    printf("%d iterations |r|/|b|=%2.16e\n",k,NORM_INF(r)/NORM_INF(b));
    printf("  -> Gradient_Conjugue ... sortie.\n");
  }

                       /* --- d�sallocation: --- */
  r0=free_Vecteur(r0); d0=free_Vecteur(d0); z0=free_Vecteur(z0); p0=free_Vecteur(p0);
  r =free_Vecteur(r ); d =free_Vecteur(d ); z =free_Vecteur(z ); D =free_Vecteur(D );
}





