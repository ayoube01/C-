/* === fichier: mes_macros.h === */

#ifndef _MES_MACROS_H
#define _MES_MACROS_H


#define Inf  (1.0/0.0)
#define NaN  (0.0/0.0)

#define Bavardage 1  /* 0,1,2,... Niveau de Verbosit� */

#define min(a,b) ( (a)<(b) ? (a) : (b) )
#define max(a,b) ( (a)>(b) ? (a) : (b) )
#define CARRE(x) ( (x)*(x) )
#define  CUBE(x) ( (x)*(x)*(x) )
#define   ABS(x) ( (x)>=0 ? (x) : -(x) )
#define  SIGN(x) ( (x)>0 ? (+1) : ( (x)<0 ? (-1) : (0) ) )

#endif /* _MES_MACROS_H */
