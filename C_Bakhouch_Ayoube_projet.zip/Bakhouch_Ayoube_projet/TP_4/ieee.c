/* ================== */
/* arithm�tique ieee: */
/* ================== */
#include "inclusions_communes.h"

/* ------------------------------------------------------------------------- */
int isFin(double x) /* d�finition des nombres finis */
{ if (-Inf<x && x<+Inf) return 1;
  else                  return 0;
} /* test: OK */

/* ------------------------------------------------------------------------- */
int isInf(double x)  /* isInf(x)=+1 (si x=+Inf), -1 (si x=-Inf), et 0 (sinon). */
{ if      (x==+Inf) return +1;
  else if (x==-Inf) return -1;
  else              return  0;
} /* test: OK */

/* ------------------------------------------------------------------------- */
int isNaN(double x)  /* d�f de NaN = autre nbre que +/-Inf ou que nbre fini */
{ if (isFin(x)==0 && isInf(x)==0) return 1;
  else                            return 0;
} /* test: OK */

/* ------------------------------------------------------------------------- */

