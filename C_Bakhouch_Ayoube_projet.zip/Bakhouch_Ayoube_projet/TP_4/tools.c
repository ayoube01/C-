/* ================== */
/*       tools.c:     */
/* ================== */

#include "inclusions_communes.h"


/* ============      Pour Vecteur:       ============== */

/* ------------------------------------------- */
/* ====   Acces aux Composantes/Champs:   ==== */
/* ------------------------------------------- */
void affecte_Vecteur(double valeur, Vecteur *V, int i)
{ assert( V );
  assert( 1<=i && i<=V->n );
  V->tab[i] = valeur;
}

double coeff_Vecteur(Vecteur *V, int i)
{ assert( V );
  assert( 1<=i && i<=V->n );
  return V->tab[i];
}

int length_Vecteur(Vecteur *V)
{ assert( V );
  return V->n;
}

/* ------------------------------------------------------------------------- */
Vecteur *zeros_Vecteur(int n)
{ int i;
  Vecteur *V=alloc_Vecteur(n);
  for (i=1; i<=n; i++) affecte_Vecteur(0.0, V, i);
  return V;
}

/* ------------------------------------------------------------------------- */
Vecteur *ones_Vecteur(int n)
{ int i;
  Vecteur *V=alloc_Vecteur(n);
  for (i=1; i<=n; i++) affecte_Vecteur(1.0, V, i);
  return V;
}

/* ------------------------------------------------------------------------- */
Vecteur *rand_Vecteur(int n)
{ int i;
  Vecteur *V=alloc_Vecteur(n);
  srand(time(0));
  for (i=1; i<=n; i++) affecte_Vecteur(rand()/(RAND_MAX+1.0), V, i);
  return V;
}



/* ============      Pour Matrice:       ============== */

/* ------------------------------------------- */
/* ====   Acces aux Composantes/Champs:   ==== */
/* ------------------------------------------- */
void affecte_Matrice(double valeur, Matrice *M, int i, int j)
{ assert( M );
  assert( 1<=i && i<=M->m );
  assert( 1<=j && j<=M->n );
  M->tab[i][j] = valeur;
}

double coeff_Matrice(Matrice *M, int i, int j)
{ assert( M );
  assert( 1<=i && i<=M->m );
  assert( 1<=j && j<=M->n );
  return M->tab[i][j];
}

int rows_Matrice(Matrice *M)
{ assert( M );
  return M->m;
}

int cols_Matrice(Matrice *M)
{ assert( M );
  return M->n;
}

/* ------------------------------------------------------------------------- */
Matrice *zeros_Matrice(int m, int n)
{ int i, j;
  Matrice *M=alloc_Matrice(m, n);

  for (i=1; i<=m; i++)
    for (j=1; j<=n; j++) affecte_Matrice(0.0, M, i, j);

  return M;
}

/* ------------------------------------------------------------------------- */
Matrice *ones_Matrice(int m, int n)
{ int i, j;
  Matrice *M=alloc_Matrice(m, n);

  for (i=1; i<=m; i++)
    for (j=1; j<=n; j++) affecte_Matrice(1.0, M, i, j);

  return M;
}

/* ------------------------------------------------------------------------- */
Matrice *rand_Matrice(int m, int n)
{ int i, j;
  Matrice *M=alloc_Matrice(m, n);

  srand(time(0));
  for (i=1; i<=m; i++)
    for (j=1; j<=n; j++) affecte_Matrice(rand()/(RAND_MAX+1.0), M, i, j);

  return M;
}




int cols_Morse(Morse *M){
    assert(M);
    return(M->cols);
}

int rows_Morse(Morse *M){
    assert(M);
    return(M->rows);
}

double Morse_coef(Morse *M, int i,int j)
{
    int k;
    if (i==1) {
        k=1;
        while (k<=M->Ifin[i])
        {
            if(M->Jtab[k]==j)
            {
                return M->Atab[k];
            }
            else
            {
                k++;
            }
        }
        return 0;
    }
    else
    {
        k=M->Ifin[i-1]+1;
        while (k<=M->Ifin[i]){
            if(M->Jtab[k]==j){
                return M->Atab[k];
            }
            else {
                k++;
            }
        }
        return 0;
    }
}


/* ------------------------------------------- */
/* ====   Conversion Matrice -> Morse :   ==== */
/* ------------------------------------------- */
Morse *Sparse_To_Morse(Matrice *A){
    Morse *M = NULL;
    int rows = A->m;
    int cols = 0;
    int i,j,k=1;
    for (i=1; i<=rows; i++)
    {
        for (j=1; j<=rows; j++)
        {
            if (A->tab[i][j] != 0)
            {
                cols++;
            }
        }
    }

    M = alloc_Morse(rows,cols);

    for (i=1; i<=rows; i++) {
        for (j=1; j<=rows; j++) {
            if (A->tab[i][j] != 0){
				M->Atab[k] = A->tab[i][j];
                M->Jtab[k] = j;
                k++;
            }
        }
        M->Ifin[i] = k-1;
    }
    return(M);
}


Morse *TriInf_To_Morse(Morse *A){
    Morse *M;
    int i,j,k;
    int n=A->rows;
    M = alloc_Morse(n,A->cols);
    k=1;
    for (i=2; i<=n; i++)
    {
        j = A->Ifin[i-1]+1;
        while (j<=A->Ifin[i] && A->Jtab[j]<=i)
        {
            k++;
            j++;
        }
    }
    alloc_Morse(n,k);
    M->Atab[1] = A->Atab[1];
    M->Jtab[1] = 1;
    M->Ifin[1] = 1;
    k=2;
    for (i=2; i<=n; i++)
    {
        j = A->Ifin[i-1]+1;

        while (j<=A->Ifin[i] && A->Jtab[j]<=i)
        {
            M->Atab[k] = A->Atab[j];
            M->Jtab[k] = A->Jtab[j];
            k++;
            j++;
        }
        M->Ifin[i] = k-1;
    }
    return(M);
}



Morse *Trisup_To_Morse(Morse *A){
    Morse *M;
    int i,j,k,l;
    int n=A->rows;
    M = alloc_Morse(n,A->cols);
    k=A->Ifin[1];
    for (i=2; i<=n; i++) {
        j=A->Ifin[i];
        while (j>=A->Ifin[i-1]+1 && A->Jtab[j]>=i) {
            k++;
            j--;
        }
    }
    alloc_Morse(n,k);
    k=1;
    for (i=1; i<=A->Ifin[1]; i++) {
        M->Atab[k] = A->Atab[i];
        M->Jtab[k] = A->Jtab[i];
        k++;
    }
    M->Ifin[1] = k-1;
    for (i=2; i<=n-1; i++)
     {
        j=A->Ifin[i-1]+1;
        while (A->Jtab[j]<i){
            j++;
        }
        for (l=j; l<=A->Ifin[i]; l++) {
            M->Atab[k] = A->Atab[l];
             M->Jtab[k] = A->Jtab[l];
            k++;
        }
        M->Ifin[i] = k-1;
    }
    M->Atab[k] = A->Atab[cols_Morse(A)];
    M->Jtab[k] = A->Jtab[cols_Morse(A)];
    M->Ifin[n] = k;
    return(M);
}



