/* ===================== */
/* ====     disp:   ==== */
/* ===================== */
#include "inclusions_communes.h"

/* ------------------------------------------------------------------------- */
void disp_Vecteur(char *message, Vecteur *V)
{ int i;

  printf("%s\n",message);
  for (i=1; i<=V->n; i++) printf("%24.16e\n",V->tab[i]);

  printf("\n");
}

/* ------------------------------------------------------------------------- */
void disp_Matrice(char *message, Matrice *M)
{ int i,j;

  printf("%s\n",message);
  for (i=1; i<=M->m; i++) {
    for (j=1; j<=M->n; j++) printf("%9.2e  ",M->tab[i][j]);
    printf("\n");
  }

  printf("\n");
}

/* ------------------------------------------------------------------------- */


void disp_Morse(char *message, Morse *M)
{	int i;
    printf("%s\n",message);
    printf("Atab = \n ");
    for (i=1; i<=M->rows; i++) {
		 printf("%9.2f  ",M->Atab[i]);
			printf("\n");
  }
      printf("\n");
      printf("Jtab = \n");
    for (i=1; i<=M->cols; i++) {
		 printf("%9.2d    ",M->Jtab[i]);
        printf("\n");
  }
   printf("\n");
    printf("Ifin = \n");
    for (i=1; i<=M->cols; i++) {
		 printf("%9.2d   ",M->Ifin[i]);
			printf("\n");
  }
   printf("\n");
}
