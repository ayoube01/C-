/* ================== */
/*       tools.c:     */
/* ================== */

#include "inclusions_communes.h"


/* ============      Pour Vecteur:       ============== */

/* ------------------------------------------- */
/* ====   Acces aux Composantes/Champs:   ==== */
/* ------------------------------------------- */
void affecte_Vecteur(double valeur, Vecteur *V, int i)
{ assert( V );
  assert( 1<=i && i<=V->n );
  V->tab[i] = valeur;
}

double coeff_Vecteur(Vecteur *V, int i)
{ assert( V );
  assert( 1<=i && i<=V->n );
  return V->tab[i];
}

int length_Vecteur(Vecteur *V)
{ assert( V );
  return V->n;
}

/* ------------------------------------------------------------------------- */
Vecteur *zeros_Vecteur(int n)
{ int i;
  Vecteur *V=alloc_Vecteur(n);
  for (i=1; i<=n; i++) affecte_Vecteur(0.0, V, i);
  return V;
}

/* ------------------------------------------------------------------------- */
Vecteur *ones_Vecteur(int n)
{ int i;
  Vecteur *V=alloc_Vecteur(n);
  for (i=1; i<=n; i++) affecte_Vecteur(1.0, V, i);
  return V;
}

/* ------------------------------------------------------------------------- */
Vecteur *rand_Vecteur(int n)
{ int i;
  Vecteur *V=alloc_Vecteur(n);
  srand(time(0));  
  for (i=1; i<=n; i++) affecte_Vecteur(rand()/(RAND_MAX+1.0), V, i);
  return V;
}



/* ============      Pour Matrice:       ============== */

/* ------------------------------------------- */
/* ====   Acces aux Composantes/Champs:   ==== */
/* ------------------------------------------- */
void affecte_Matrice(double valeur, Matrice *M, int i, int j)
{ assert( M );
  assert( 1<=i && i<=M->m );
  assert( 1<=j && j<=M->n );
  M->tab[i][j] = valeur;
}

double coeff_Matrice(Matrice *M, int i, int j)
{ assert( M );
  assert( 1<=i && i<=M->m );
  assert( 1<=j && j<=M->n );
  return M->tab[i][j];
}

int nrows_Matrice(Matrice *M)
{ assert( M );
  return M->m;
}

int ncols_Matrice(Matrice *M)
{ assert( M );
  return M->n;
}

/* ------------------------------------------------------------------------- */
Matrice *zeros_Matrice(int m, int n)
{ int i, j;
  Matrice *M=alloc_Matrice(m, n);
  
  for (i=1; i<=m; i++) 
    for (j=1; j<=n; j++) affecte_Matrice(0.0, M, i, j);
    
  return M;
}

/* ------------------------------------------------------------------------- */
Matrice *ones_Matrice(int m, int n)
{ int i, j;
  Matrice *M=alloc_Matrice(m, n);
  
  for (i=1; i<=m; i++) 
    for (j=1; j<=n; j++) affecte_Matrice(1.0, M, i, j);
    
  return M;
}

/* ------------------------------------------------------------------------- */
Matrice *rand_Matrice(int m, int n)
{ int i, j;
  Matrice *M=alloc_Matrice(m, n);
  
  srand(time(0));  
  for (i=1; i<=m; i++) 
    for (j=1; j<=n; j++) affecte_Matrice(rand()/(RAND_MAX+1.0), M, i, j);
    
  return M;
}




int ncols_Morse(Morse *M){
    assert(M);
    return(M->ncols);
}

int nrows_Morse(Morse *M){
    assert(M);
    return(M->nrows);
}

double Morse_coef(Morse *M, int i,int j)
{
    int k;
    
    if (i==1) {
        k=1;
        while (k<=M->ifin[i])
        {
            if(M->jtab[k]==j)
            {
                return M->atab[k];
            }
            else 
            {
                k++;
            }
        }
        return 0;
    }
    else 
    {
        k=M->ifin[i-1]+1;
        while (k<=M->ifin[i]){
            if(M->jtab[k]==j){
                return M->atab[k];
            }
            else {
                k++;
            }
        }
        return 0;
    }
}




/* ------------------------------------------- */
/* ====   Conversion Matrice -> Morse :   ==== */
/* ------------------------------------------- */
Morse *Sparse2Morse(Matrice *A){
    Morse *M = NULL;
    int nrows = A->m;
    int ncols = 0;
    int i,j,k=1;
   

    for (i=1; i<=nrows; i++) 
    {
        for (j=1; j<=nrows; j++) 
        {
            if (A->tab[i][j] != 0)
            {
                ncols++;
            }
        }
    }
    
    M = alloc_Morse(nrows,ncols);
    
    for (i=1; i<=nrows; i++) {
        for (j=1; j<=nrows; j++) {
            if (A->tab[i][j] != 0){
				M->atab[k] = A->tab[i][j];
                M->jtab[k] = j;
                k++;
            }
        }
        M->ifin[i] = k-1;
    }
    return(M);
}


Morse *TriInf_Morse(Morse *A){
    Morse *M;
    
    int i,j,k;
    int n=A->nrows;
    
    M = alloc_Morse(n,A->ncols);

    
    k=1;
    
    for (i=2; i<=n; i++) 
    {
        j = A->ifin[i-1]+1;
        while (j<=A->ifin[i] && A->jtab[j]<=i) 
        {
            k++;
            j++;
        }
    }

    alloc_Morse(n,k);
    
    M->atab[1] = A->atab[1];
    M->jtab[1] = 1;
    M->ifin[1] = 1;

    k=2;
    
    for (i=2; i<=n; i++) 
    {
        j = A->ifin[i-1]+1;
        
        while (j<=A->ifin[i] && A->jtab[j]<=i) 
        {
            M->atab[k] = A->atab[j];
            M->jtab[k] = A->jtab[j];
            k++;
            j++;
        }
   
        M->ifin[i] = k-1;
    }
    return(M);
}



Morse *TriSup_Morse(Morse *A){
    Morse *M;
    int i,j,k,l;
    int n=A->nrows;
    
    
    M = alloc_Morse(n,A->ncols);
    
    k=A->ifin[1];
    for (i=2; i<=n; i++) {
        j=A->ifin[i];
        while (j>=A->ifin[i-1]+1 && A->jtab[j]>=i) {
            k++;
            j--;
        }
    }
    
    alloc_Morse(n,k);
    
    k=1;
    for (i=1; i<=A->ifin[1]; i++) {
        M->atab[k] = A->atab[i];
        M->jtab[k] = A->jtab[i];
        k++;
    }
    M->ifin[1] = k-1;
    for (i=2; i<=n-1; i++)
     {
        j=A->ifin[i-1]+1;
        while (A->jtab[j]<i){
            j++;
        }
        for (l=j; l<=A->ifin[i]; l++) {
            M->atab[k] = A->atab[l];
             M->jtab[k] = A->jtab[l];
            k++;
        }
        M->ifin[i] = k-1;
    }
    M->atab[k] = A->atab[ncols_Morse(A)];
    M->jtab[k] = A->jtab[ncols_Morse(A)];
    M->ifin[n] = k;
    return(M);
}
