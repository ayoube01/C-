/* === fichier: mes_entetes.h === */

#ifndef _MES_ENTETES_H
#define _MES_ENTETES_H

/* =========================== */
/* arithm�tique ieee (ieee.c): */
/* =========================== */
int isFin(double x); /* d�finition des nombres finis */
int isInf(double x); /* isInf(x)=+1 (si x=+Inf), -1 (si x=-Inf), et 0 (sinon). */
int isNaN(double x); /* d�f de NaN = autre nbre que +/-Inf ou que nbre fini */


/* =============================== */
/* allocation dynamique (alloc.c): */
/* =============================== */

/* --- des tableaux: --- */
double *alloc_dtab_1d(int n);
double * free_dtab_1d(double *v);

int *alloc_itab_1d(int n);
int * free_itab_1d(int *v);

double **alloc_dtab_2d(int m, int n);
double ** free_dtab_2d(double **M);

/* --- des structures: --- */
Matrice *alloc_Matrice(int m, int n);
Matrice * free_Matrice(Matrice *M);

Vecteur *alloc_Vecteur(int n);
Vecteur * free_Vecteur(Vecteur *V);

Morse *alloc_Morse(int n, int ncols);
Morse * free_Morse(Morse *M);


/* ===================== */
/* ====   disp.c:   ==== */
/* ===================== */
void disp_Vecteur(char *message, Vecteur *V);
void disp_Matrice(char *message, Matrice *M);
void disp_Morse(char *message, Morse *M);


/* ===================== */
/* ====   save.c:   ==== */
/* ===================== */
void     save_Vecteur_pour_Matlab(char *nomfich, Vecteur *x);
void     save_Vecteur(char *nomfich, Vecteur *x);
Vecteur *load_Vecteur(char *nomfich);
void     save_Matrice(char *nomfich, Matrice *M);
Matrice *load_Matrice(char *nomfich);

/* ================== */
/*       tools.c:     */
/* ================== */
void   affecte_Vecteur(double valeur, Vecteur *V, int i); /* V(i)=valeur */
double   coeff_Vecteur(Vecteur *V, int i);
int     length_Vecteur(Vecteur *V);

Vecteur *zeros_Vecteur(int n); /* allocation + affectation a zeros */
Vecteur * ones_Vecteur(int n); /* allocation + affectation a uns */
Vecteur * rand_Vecteur(int n);

void    affecte_Matrice(double valeur, Matrice *M, int i, int j);
double    coeff_Matrice(Matrice *M, int i, int j);
int       nrows_Matrice(Matrice *M);
int       ncols_Matrice(Matrice *M);

void    affecte_Morse(double valeur, Matrice *M, int i, int j);
double    coeff_Matrice(Matrice *M, int i, int j);
int       nrows_Matrice(Matrice *M);
int       ncols_Matrice(Matrice *M);

Matrice  *zeros_Matrice(int m, int n);
Matrice  * ones_Matrice(int m, int n);
Matrice  * rand_Matrice(int m, int n);



double    Morse_coef(Morse *M, int i, int j);
int       nrows_Morse(Morse *M);
int       ncols_Morse(Morse *M);

Morse *Sparse2Morse(Matrice *A);
Morse *TriInf_Morse(Morse *A);
Morse *TriSup_Morse(Morse *A);

/* ============ */
/* BLAS: blas.c */
/* ============ */

/* -------------------------- */
/* --- BLAS de bas niveau --- */
/* -------------------------- */
double dot(double *v, double *w, int d, int f);          /*          v(d:f)'*w(d:f)    */
void saxpy(double *z, double alpha, double *x, double *y, int d, int f); 
                                                         /* z(d:f) = a.*x(d:f)+y(d:f)' */
void xpy(double *z, double *x, double *y, int d, int f); /* z(d:f) = x(d:f)+y(d:f)     */
void xmy(double *z, double *x, double *y, int d, int f); /* z(d:f) = x(d:f)-y(d:f)     */
void xfy(double *z, double *x, double *y, int d, int f); /* z(d:f) = x(d:f).*y(d:f)    */
void xdy(double *z, double *x, double *y, int d, int f); /* z(d:f) = x(d:f)./y(d:f)    */
void opu(double **R, double a, double *x, double *y, int d, int f);
              /* R(d:f,d:f) += a.*x(d:f)*y(d:f)' !! seulement pour matrices CARREES */
void matvec(double *y, double **A, double *x, int m, int n);  
                                                      /* y(1:m) = A(1:m,1:n)*x(1:n) */
void residu(double *r, double *b, double **A, double *x, int m, int n);  
                                               /* r(1:m) = b(1:m)-A(1:m,1:n)*x(1:n) */
void descente(double *x, double **L, double *b, int d, int f);
                         /* x(d:f)? / L(d:f,d:f)x(d:f) = b(d:f) avec L=triang. inf. */
void remontee(double *x, double **U, double *b, int d, int f);
                          /* x(d:f)? / U(d:f,d:f)x(d:f) = b(d:f) avec U=triang. sup.*/

/* --------------------------- */
/* --- BLAS de haut niveau --- */
/* --------------------------- */
double DOT     (Vecteur *v, Vecteur *w);                             /*     v'*w        */
void   SAXPY   (Vecteur *z, double a, Vecteur *x, Vecteur *y);       /* z = a.*x+y      */
void   XPY     (Vecteur *z, Vecteur *x, Vecteur *y);                 /* z = x+y         */
void   XMY     (Vecteur *z, Vecteur *x, Vecteur *y);                 /* z = x-y         */
void   XFY     (Vecteur *z, Vecteur *x, Vecteur *y);                 /* z = x.*y        */
void   XDY     (Vecteur *z, Vecteur *x, Vecteur *y);                 /* z = x./y        */
double NORM    (Vecteur *x);                         /* ||x||_2 = sqrt( (x|x) )         */
double NORM_INF(Vecteur *x);                         /* ||x||_inf = max_{1<=i<=n} |x_i| */
void   OPU     (Matrice *R, double a, Vecteur *x, Vecteur *y, int d, int f);  
                                /* R += a.*x*y' !! seulement pour matrices CARREES */
void MATVEC  (Vecteur *y, Matrice *A, Vecteur *x);                    /* y = A*x   */
void RESIDU  (Vecteur *r, Vecteur *b, Matrice *A, Vecteur *x);        /* r = b-A*x */
void DESCENTE(Vecteur *x, Matrice *A, Vecteur *b);     /* x? | A*x=b ou A tri. inf.*/
void REMONTEE(Vecteur *x, Matrice *A, Vecteur *b);     /* x? | A*x=b ou A tri. sup.*/
void VecCPY  (Vecteur *z, Vecteur *x);                                /* z = x     */


void MATVECT_MORSE(Vecteur *y, Morse *M, Vecteur *x);                    /* y = A*x   */
void RESIDU_MORSE(Vecteur *r, Vecteur *b, Morse *M, Vecteur *x);        /* r = b-A*x */
void DESCENTE_MORSE(Vecteur *x, Morse *M, Vecteur *b);     /* x? | A*x=b ou A tri. inf.*/
void REMONTEE_MORSE(Vecteur *x, Morse *M, Vecteur *b);     /* x? | A*x=b ou A tri. sup.*/

/* ========================================================================= */
/* ------------------------ M�thodes It�ratives  --------------------------- */
/* ========================================================================= */

void Jacobi_Matrice(Vecteur *x, Matrice *A, Vecteur *b, Vecteur *x0, 
                       double eps, int kmax);
void Gauss_Seidel_Matrice(Vecteur *x, Matrice *A, Vecteur *b, Vecteur *x0, 
                       double eps, int kmax);
void Relaxation_Matrice(Vecteur *x, Matrice *A, Vecteur *b, Vecteur *x0, 
                       double eps, int kmax, double w);
void Gradient_Conjugue_Matrice(Vecteur *x, Matrice *A, Vecteur *b, Vecteur *x0, 
                       double eps, int kmax);
                       
                       
void Jacobi_Morse(Vecteur *x, Morse *A, Vecteur *b, Vecteur *x0, double eps, int kmax);
void Gauss_Seidel_Morse(Vecteur *x, Morse *A, Vecteur *b, Vecteur *x0, double eps, int kmax);
void Relaxation_Morse(Vecteur *x, Morse *A, Vecteur *b, Vecteur *x0, double eps, int kmax, double w);



#endif /* _MES_ENTETES_H */
